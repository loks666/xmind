## 51job自动投简历脚本 ##
1. 请在51job网站编辑好自己的简历
2. 在文件内改为自己的账号密码
3. 在文件内输入自己要投递的岗位
4. 运行脚本

----------



- PS：本脚本依赖 [selenium](https://selenium-python-zh.readthedocs.io/en/latest/getting-started.html) 自动化测试框架，谷歌浏览器驱动已提供，其他浏览器驱动请自行解决
- 更多教程请移步 [李飞飞的博客](http://www.superxiang.com)