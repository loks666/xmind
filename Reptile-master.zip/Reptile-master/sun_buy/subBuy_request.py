import csv
import json

import requests
from PIL import Image
from pytesseract import image_to_string

from test import resp

auth_code = 'auth_code.png'
session = requests.session()


#  获取验证码
def get_auth_code():
    global session
    session.get('http://biz.smpaa.cn/ysxtqxcp/')
    response = session.get('http://biz.smpaa.cn/ysxtqxcp/myCaptcha')
    with open(auth_code, 'wb') as f:
        f.write(response.content)


# 图片转变中度灰，识别不出
def convert_img():
    img = Image.open(auth_code)
    imgry = img.convert('L')
    binary = imgry.point(get_bin_table(), '1')
    binary.save('binary.png')
    text = image_to_string(img)
    print(text)


# 降噪，转换效果不理想
def get_bin_table(threshold=115):
    '''
    获取灰度转二值的映射table
    0表示黑色,1表示白色
    '''
    table = []
    for i in range(256):
        if i < threshold:
            table.append(0)
        else:
            table.append(1)
    return table


# 图片二值化
def two_value():
    im = Image.open(auth_code)
    # 图像二值化
    data = im.getdata()
    w, h = im.size
    black_point = 0

    for x in range(1, w - 1):
        for y in range(1, h - 1):
            mid_pixel = data[w * y + x]  # 中央像素点像素值
            if mid_pixel < 50:  # 找出上下左右四个方向像素点像素值
                top_pixel = data[w * (y - 1) + x]
                left_pixel = data[w * y + (x - 1)]
                down_pixel = data[w * (y + 1) + x]
                right_pixel = data[w * y + (x + 1)]

                # 判断上下左右的黑色像素点总个数
                if top_pixel < 10:
                    black_point += 1
                if left_pixel < 10:
                    black_point += 1
                if down_pixel < 10:
                    black_point += 1
                if right_pixel < 10:
                    black_point += 1
                if black_point < 1:
                    im.putpixel((x, y), 255)
                # print(black_point)
                black_point = 0

    im.save('test.png')


# 识别验证码
def discern_code():
    img = Image.open(auth_code)
    text = image_to_string(img)
    print(text)


def get_buy_data():
    global session
    url = 'http://biz.smpaa.cn/ysxtqxcp/cpcx/hcxx/queryCgd/yq'
    headers = {
        'Accept': 'text/plain, */*; q=0.01',
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'zh-CN,zh;q=0.9',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        'Content-Length': '100',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        # 'Cookie': 'JSESSIONID=OP57pL9NmjTBQwbLzOiNkaXtoyVH-Wb0N1zy5SAjL8MqV4VnPMCi!-2060801452',
        'Host': 'biz.smpaa.cn',
        'Origin': 'http://biz.smpaa.cn',
        'Pragma': 'no-cache',
        'Referer': 'http://biz.smpaa.cn/ysxtqxcp/menu?p=/pub/cpcx/cgd/cgdxxcx_yq&menuid=10202004&_t=348616&_winid=w2185',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.9 Safari/537.36',
        'X-Requested-With': 'XMLHttpRequest',
    }

    form_data = {
        'hcddmxid': '',
        'scqybm': '',
        'yybm': '',
        'psdbm': '',
        'cglx': '',
        'pm': '',
        'tjfs': '',
        'ddmxzt': '',
        'pageIndex': '1',
        'pageSize': '20',
        'sortField': '200'
    }
    response = session.post(url, headers=headers, data=form_data)
    with open('data.txt', 'w') as f:
        f.write(response.text)
    print(response.text)


def login():
    global session
    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,'
                  'application/signed-exchange;v=b3;q=0.9',
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'zh-CN,zh;q=0.9',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        'Content-Length': '50',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Host': 'biz.smpaa.cn',
        'Origin': 'http://biz.smpaa.cn',
        'Pragma': 'no-cache',
        'Referer': 'http://biz.smpaa.cn/ysxtqxcp/login.jsp',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
                      'Chrome/81.0.4044.9 Safari/537.36',
    }
    data = {'loginName': 'zk1509005', 'password': '18412914', 'captcha': input('验证码：')}
    session.post('http://biz.smpaa.cn/ysxtqxcp/login', headers=headers, data=data)


def get_invoice_data():
    operation()
    global session
    url = 'http://biz.smpaa.cn/ysxtqxcp/cpcx/hcxx/queryFpxx/yq'
    headers = {
        "Accept": "text/plain, */*; q=0.01",
        "Accept-Encoding": "gzip, deflate",
        "Accept-Language": "zh-CN,zh;q=0.9",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
        "Content-Length": "146",
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "Cookie": "JSESSIONID=CIVdvjgZiE-UmJRQynE-v0LHnulYbReTS4kmW4J9IjcjXfHvser7!-1424926915",
        "Host": "biz.smpaa.cn",
        "Origin": "http://biz.smpaa.cn",
        "Pragma": "no-cache",
        "Referer": "http://biz.smpaa.cn/ysxtqxcp/menu?p=/pub/cpcx/fp/fpxxcx_yq&menuid=10202006&_t=944947&_winid=w3969",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.9 Safari/537.36",
        "X-Requested-With": "XMLHttpRequest",
    }

    form_data = {
        "fph": "",
        "cglx": "",
        "scqybm": "",
        "fpzt": "20",
        "fpscsjFrom": "20170401",
        "fpscsjTo": "20200409",
        "pm": "",
        "fprqFrom": "",
        "fprqTo": "",
        "yybm": "",
        "psdbm": "",
        "pageIndex": "0",
        "pageSize": "100",
        "sortField": "",
        "sortOrder": "",
    }

    response = session.post(url, headers=headers, data=form_data)
    # 计算总页数
    total = response.json()['total']
    pages = total // 100
    if total % 100 > 0:
        pages += 1

    for i in range(pages):
        form_data['pageIndex'] = i
        response = session.post(url, headers=headers, data=form_data)
        save_to_csv(response)
        # csvfile = open('goods.csv', 'w', newline='', encoding='utf-8')
        # writer = csv.writer(csvfile)
        # writer.writerow(
        #     ['发票编号', '发票代码', '发票号', '发票状态', '医院', '医院配送点', '价税合计', '发票类型', '发票日期', '发票上传时间', '发票验收时间', '发票备注'])
        # writer.writerow(
        #     ['hcfpid', 'fpdm', 'fph', 'fpzt', 'yymc', 'psdmc', 'fphsje', 'fplx', 'fprq', 'fpscsj', '发票验收时间', '发票备注'])
        # with open('data.txt', 'w') as f:
        #     f.write(response.text)


def save_to_csv(response):
    json_data = response.json()['data']
    data = []
    for item in json_data:
        data.append(
            [item['hcfpid'], item['fpdm'], item['fph'], item['fpzt'], item['yymc'], item['psdmc'],
             str(item['fphsje']) + '.0000',
             item['fplx'], item['fprq'], item['fpscsj']])
    with open('data.csv', 'a+', encoding='utf-8') as f:
        f.write('\n'.join([','.join(i) for i in data]))
        f.write('\n')


def operation():
    global session
    url = 'http://biz.smpaa.cn/ysxtqxcp/cpcx/hcxx/synchronizeFp/yq'
    headers = {
        "Accept": "*/*",
        "Accept-Encoding": "gzip, deflate",
        "Accept-Language": "zh-CN,zh;q=0.9",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
        "Content-Length": "0",
        # "Cookie": "JSESSIONID=CIVdvjgZiE-UmJRQynE-v0LHnulYbReTS4kmW4J9IjcjXfHvser7!-1424926915",
        "Host": "biz.smpaa.cn",
        "Origin": "http://biz.smpaa.cn",
        "Pragma": "no-cache",
        "Referer": "http://biz.smpaa.cn/ysxtqxcp/menu?p=/pub/cpcx/fp/fpxxcx_yq&menuid=10202006&_t=944947&_winid=w3969",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.9 Safari/537.36",
        "X-Requested-With": "XMLHttpRequest",
    }

    response = session.post(url, headers=headers)
    print('操作请求结果:  ' + response.text)


if __name__ == '__main__':
    get_auth_code()
    login()
    get_invoice_data()
